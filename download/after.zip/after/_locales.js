var locales = {
  en: {
    headline: "Drink milk",
    p1: "5 Proven Health Benefits of Milk"
  },
  de: {
    headline: "Trink Milch",
    p1: "5 Bewährte gesundheitliche Vorteile von Milch"
  },
  pl: {
    headline: "Pij mleko",
    p1: "5 sprawdzonych benefitów mleka"
  }
} 