var locales = {
  en: {
    headline: "Drink milk",
    p1: "5 Proven Health Benefits of Milk"
  },
  pl: {
    headline: "Pij mleko",
    p1: "5 sprawdzonych benefitów mleka"
  }
} 