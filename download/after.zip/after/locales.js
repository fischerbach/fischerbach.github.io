var locales = {
  "en": {
    //limit 10 chars
    "headline": "Drink milk",
    "p1": "5 Proven Health Benefits of Milk"
  },
  "pl": {
    "headline": "Pij mleko",
    "p1": "5 sprawdzonych benefitów mleka"
  }
}
